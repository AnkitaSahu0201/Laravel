<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
       <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
       
    </head>
    <body>
        <div style="height:40px">&nbsp</div>
        <h1 style="text-align:center; color:coral">Registration Form</h1><br>
        
        <div class="container">
            <div class="row">
            <div class="col-md-4">
                <input type="hidden" name="id" value="<?php echo e($registration->id); ?>" >
            </div>
                <div class="col-md-4">
                    <form action="<?php echo e(route('registration.update', $registration->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div>
                            <label>Name</label>
                            <input type="text"  name="fname" class="form-control" value="<?php echo e($registration->name); ?>" required></br><br>
                        </div>
                        <div>
                            <label>Phone</label>
                            <input type="tel"  name="phone"  minlength="10" maxlength="10" class="form-control" value="<?php echo e($registration->phone); ?>" required></br><br>
                        </div>
                        <div>
                        <label>Address</label>
                            <input type="text" class="form-control" name="address" id="address" class="form-control" value="<?php echo e($registration->address); ?>"></textarea><br>
                        </div>
                        <div>
                        <button type="submit" class="btn btn-primary" name="btnadd" id="btnadd">Submit</button>
                        </div>
                    </form>
                </div>
                <div class="col-md-4"></div>
            </div>
        </div>
    </body>
</html><?php /**PATH C:\xampp\htdocs\laravel\form\resources\views/edit.blade.php ENDPATH**/ ?>