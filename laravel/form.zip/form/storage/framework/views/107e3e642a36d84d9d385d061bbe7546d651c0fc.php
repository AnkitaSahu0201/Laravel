<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <body>
        <div class ="container">
            <div class="row">
                <div style="height:40px">&nbsp</div>
                <h2 style="text-align:center; color:coral">Registrations</h2>

                <table class= "table table-striped">
                    <tr>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Address</th>
                    </tr>
                    <h5 style="text-align:center">Student Details</h5>
                    <?php $__currentLoopData = $regis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($registration->name); ?></td>
                            <td><?php echo e($registration->phone); ?></td>
                            <td><?php echo e($registration->address); ?></td>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </body>
</html>


<?php /**PATH C:\xampp\htdocs\laravel\form\resources\views/pdfview.blade.php ENDPATH**/ ?>