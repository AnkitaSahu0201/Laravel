<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
        <div class ="container">
            <div class="row">
                <div style="height:40px">&nbsp</div>
                <h2 style="text-align:center; color:coral">Registrations</h2>
            
                <div>
                    <a class ="btn btn-success" href="<?php echo e(route('registration.create')); ?>">New Student</a><br><br>
                </div>
                <div>
                <a class ="btn btn-success" href="import">Import/ Export Data</a>
                <a class ="btn btn-success" href="<?php echo e(url('/pdfdownload')); ?>">Download Pdf</a><br><br>
                </div>
        

                <!-- <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php endif; ?> -->


                <table class= "table table-striped">
                    <tr>
                        <th>Id.</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>Action</th>
                    </tr>
                    <h5 style="text-align:center">Show Details</h5>
                    <?php $__currentLoopData = $registration; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($registration->id); ?></td>
                            <td><?php echo e($registration->name); ?></td>
                            <td><?php echo e($registration->phone); ?></td>
                            <td><?php echo e($registration->address); ?></td>
                            <td>
                                <form method="POST" action="<?php echo e(route('registration.destroy',$registration->id)); ?>">
                                    <a class="btn btn-primary" href="<?php echo e(route('registration.edit', $registration->id)); ?>">Edit</a>
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <button  class="btn btn-danger delete-user" value="Delete">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </body>
</html>


<?php /**PATH C:\xampp\htdocs\laravel\form\resources\views//registrationform.blade.php ENDPATH**/ ?>