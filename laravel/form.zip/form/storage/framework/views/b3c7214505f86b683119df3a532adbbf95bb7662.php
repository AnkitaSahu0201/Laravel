<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
       <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
       
    </head>
    <body>
        <div style="height:40px">&nbsp</div>
        <h1 style="text-align:center; color:coral">Registration Form</h1><br>

        <!-- <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?> -->

        <div class="container">
            <div class="row">
            <div class="col-md-4"></div>
                <div class="col-md-4">
                    <form action="<?php echo e(url('/registration')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div>
                            <label>Name</label>
                            <input type="text"  name="name" class="form-control" required></br><br>
                        </div>
                        <div>
                            <label>Phone</label>
                            <input type="tel"  name="phone"  minlength="10" maxlength="10" class="form-control" required></br><br>
                        </div>
                        <div>
                        <label>Address</label>
                            <textarea  rows="4" cols="20" class="form-control" name="address" id="address" class="form-control"></textarea><br>
                        </div>
                        <div>
                        <button type="submit" class="btn btn-primary" name="btnadd" id="btnadd">Submit</button>
                        </div>
                    </form>
                </div>
                <div class="col-md-4"></div>
            </div>
        </div>
    </body>
</html><?php /**PATH C:\xampp\htdocs\laravel\form\resources\views/create.blade.php ENDPATH**/ ?>