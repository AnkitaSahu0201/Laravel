<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <body>
        <div class ="container">
            <div class="row">
                <div style="height:40px">&nbsp</div>
                <h2 style="text-align:center; color:coral">Registrations</h2>

                <table class= "table table-striped">
                    <tr>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Address</th>
                    </tr>
                    <h5 style="text-align:center">Student Details</h5>
                    @foreach($regis as $registration)
                        <tr>
                            <td>{{ $registration->name}}</td>
                            <td>{{ $registration->phone}}</td>
                            <td>{{ $registration->address}}</td>
                            </td>
                        </tr>
                    @endforeach
                </table>
            </div>
        </div>
    </body>
</html>


