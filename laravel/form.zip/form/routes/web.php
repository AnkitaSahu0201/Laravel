<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

// Route::get('/registrationform', function () {
//     return view('registrationform');
// });
Route::get('/', 'RegistrationController@registrationform')->name('registration.registrationform');
Route::get('/registration', 'RegistrationController@create')->name('registration.create');
Route::post('/registration', 'RegistrationController@store')->name('registration.store');
Route::delete('/registration/{id}', 'RegistrationController@destroy')->name('registration.destroy');
Route::get('/registration/{id}', 'RegistrationController@edit')->name('registration.edit');
Route::post('/registration/{id}', 'RegistrationController@update')->name('registration.update');
Route::get('/importExportView', 'FileDataController@importExportView');
Route::get('/export', 'FileDataController@export')->name('registration.export');
Route::view('/import', 'import');
Route::post('/import', 'FileDataController@import')->name('registration.import');
Route::get('/pdfview', 'ItemController@pdfview')->name('registration.pdfview');
Route::get('/pdfdownload', 'ItemController@pdfdownload')->name('registration.pdfdownload');
Route::get('/users', 'UserController@show');


// Route::post('registration/{id}',function ($id) {
//     return 'update '.$id;
// });

?>

