<?php

namespace App\Exports;
use Illuminate\Support\Facades\DB;
use App\registration;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class ExportUsers implements FromCollection, WithHeadings
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
       
 
    $user = registration::select('name', 'phone', 'address')->get();
            return $user;
    }

    public function headings(): array
    {
        return ['name',
        'phone',
        'address'];
    }
}
