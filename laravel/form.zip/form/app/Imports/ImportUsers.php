<?php

namespace App\Imports;

use App\registration;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;

class ImportUsers implements ToModel, WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        Validator::make($rows->toArray(), [
            '*.name' => 'required',
            '*.phone' => 'required',
            '*.address' => 'required',
        ])->validate();

        return new registration([ 
            'name'     => $row['name'],
            'phone'    => $row['phone'], 
            'address' => $row['address'],
        ]);
    }
}
