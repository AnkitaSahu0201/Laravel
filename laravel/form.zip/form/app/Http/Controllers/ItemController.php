<?php
namespace App\Http\Controllers;

use App\registration;
use App\Http\Requests;
use Illuminate\Http\Request;
use Redirect;
use PDF;

class ItemController extends Controller
{
    public function pdfview(Request $request)
    {
        $regis = registration::all(); 
        return view('pdfview', compact('regis'));
    }
    public function pdfdownload(){
        $regis = registration::all();
        $pdf = PDF::loadView('pdfview', compact('regis'));
        return $pdf->download('userrecord.pdf');
        // return PDF::download('userrecord.pdf');
    }

}
?>
