<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\User;
  
class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
        $registration = User::paginate(10);
        return view('/users',compact('registration'));
    }
}