<?php

namespace App\Http\Controllers;

use App\registration;
use Illuminate\Http\Request;

class RegistrationController extends Controller
{
    public function registrationform(Request $request)
    {
        $registration = registration::all(); 
        // dd($registration);    
        return view('registrationform', compact('registration','registration'));    
    }

    public function create()
    {
        return view('create');
    }

    public function store(Request $request)
    {
        registration::create([
            'name' => $request->fname,
            'phone' => $request->phone,
            'address' => $request->address,
            'created_at' => now(),
        ]);
        return redirect()->route('registration.registrationform')->with('success','form details submitted');
    }

    public function destroy(registration $id)
    {
        $id -> delete(); 
        // dd($registration);    
        return redirect()->route('registration.registrationform')->with('success','form details deleted');
    }

    public function edit(registration $id)
    {
        return view('edit')->with('registration', $id);
    }
    
    
    function update(Request $request){
        $data  = registration::find($request->id);
        $data ->name = $request->fname;
        $data ->phone = $request->phone;
        $data ->address = $request->address;
        $data->save();
        return redirect('/');

    }
    
    // public function boot()
    // {
    //     Route::pattern('name', '[a-z]+');
    
    //     parent::boot();
    // }
    
}
?>

