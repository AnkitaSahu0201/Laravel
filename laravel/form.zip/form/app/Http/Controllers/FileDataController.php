<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Exports\ExportUsers;
use App\Imports\ImportUsers;
use Maatwebsite\Excel\Facades\Excel;

class FileDataController extends Controller
{
 
    public function importExportView()
    {
       return view('import');
    }
   
  
    public function export() 
    {
        return Excel::download(new ExportUsers, 'userfile.csv');
    }
   
   
    public function import(Request $request) 
    {
        Excel::import(new ImportUsers,$request->file('file'));   
        return response()->json([
            'message' => 'Products are successfully imported.'
        ]);
    }
}
